#include "motion.h"
#include "stepper.h"
#include "limit.h"
#include "servo.h"
#include "comm_can.h"
#include "comm_uart.h"
#include "key.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include <stdio.h>

QueueHandle_t     g_motion_queue;
QueueHandle_t     g_can_cmd_queue;
SemaphoreHandle_t g_move_done_sem;
SemaphoreHandle_t g_home_sem;
volatile uint8_t  g_sys_status = ST_IDLE;
volatile uint8_t  g_auto_mode  = 0;

/* ---------- 运动执行原语 ---------- */

static int32_t mm_to_steps(float mm)
{
    return (int32_t)(mm * STEPS_PER_MM);
}

/* 移动到 (x_mm, y_mm)，阻塞等待到位或超时/急停；返回 0=成功 */
static int motion_move_mm(float x_mm, float y_mm)
{
    int32_t dx, dy;
    int32_t cur_x = stepper_x_steps();
    int32_t cur_y = stepper_y_steps();

    /* 软件行程保护 */
    if (x_mm < 0.0f || x_mm > X_TRAVEL_MM || y_mm < 0.0f || y_mm > Y_TRAVEL_MM) {
        g_sys_status = ST_ERROR;
        comm_can_send_err(0x0002);
        return -1;
    }

    dx = mm_to_steps(x_mm) - cur_x;
    dy = mm_to_steps(y_mm) - cur_y;

    stepper_start_line(dx, dy);
    if (xSemaphoreTake(g_move_done_sem, pdMS_TO_TICKS(MOVE_TIMEOUT_MS)) != pdPASS) {
        stepper_stop();
        g_sys_status = ST_ERROR;
        comm_can_send_err(0x0003);      /* 超时 */
        return -1;
    }
    if (g_estop) {
        g_sys_status = ST_ERROR;
        comm_can_send_err(0x0001);      /* 限位/急停 */
        return -1;
    }
    return 0;
}

static int motion_home_impl(void)
{
    int32_t limit_trip = 0;

    g_sys_status = ST_HOME;
    g_estop = 0;
    limit_init();

    /* 朝 X-、Y- 慢速回零：走一个长距离直线，触发限位即停 */
    stepper_start_line(-500000, -500000);
    xSemaphoreTake(g_home_sem, pdMS_TO_TICKS(MOVE_TIMEOUT_MS));
    stepper_stop();

    if (g_limit_xn) limit_trip |= 0x01;
    if (g_limit_yn) limit_trip |= 0x02;

    /* 以 X-、Y- 限位为新原点 */
    stepper_x_reset();
    stepper_y_reset();
    return (limit_trip != 0) ? 0 : -1;   /* 至少一个轴触发才算成功 */
}

/* ---------- 抓取流程 ---------- */

static void auto_pick(MotionCmd_t *cmd)
{
    g_sys_status = ST_AUTO;

    /* 1. 移到目标点 */
    if (motion_move_mm((float)cmd->x_mm, (float)cmd->y_mm) != 0)
        return;

    /* 2. 抓取 */
    g_sys_status = ST_GRIP;
    servo_grip_close();
    vTaskDelay(pdMS_TO_TICKS(300));

    /* 3. 移投放点 */
    if (motion_move_mm(DUMP_X_MM, DUMP_Y_MM) != 0)
        return;

    /* 4. 松爪 */
    servo_grip_open();
    vTaskDelay(pdMS_TO_TICKS(200));

    g_sys_status = ST_DONE;
}

/* ---------- 对外接口（按键/CAN 调用） ---------- */

void motion_toggle_mode(void)
{
    g_auto_mode ^= 1;
}

void motion_request_home(void)
{
    uint8_t cmd = CAN_CMD_HOME;
    xQueueSend(g_can_cmd_queue, &cmd, 0);
}

void motion_stop(void)
{
    stepper_stop();
    g_sys_status = ST_IDLE;
}

void motion_reset_pos(void)
{
    stepper_x_reset();
    stepper_y_reset();
}

/* ---------- 任务 ---------- */

void motion_init(void)
{
    g_motion_queue  = xQueueCreate(4, sizeof(MotionCmd_t));
    g_can_cmd_queue = xQueueCreate(4, sizeof(uint8_t));
    g_move_done_sem = xSemaphoreCreateBinary();
    g_home_sem      = xSemaphoreCreateBinary();
}

void vMotionTask(void *arg)
{
    MotionCmd_t cmd;
    uint8_t ccmd;

    (void)arg;
    for (;;) {
        /* 先处理 CAN 命令（高优先级），再处理坐标 */
        if (xQueueReceive(g_can_cmd_queue, &ccmd, 0) == pdPASS) {
            switch (ccmd) {
            case CAN_CMD_HOME:   motion_home_impl(); break;
            case CAN_CMD_STOP:   motion_stop(); break;
            case CAN_CMD_MANUAL: g_auto_mode = 0; break;
            case CAN_CMD_AUTO:   g_auto_mode = 1; break;
            default: break;
            }
            continue;
        }

        if (xQueueReceive(g_motion_queue, &cmd, portMAX_DELAY) == pdPASS) {
            if (cmd.flag && g_auto_mode)
                auto_pick(&cmd);
            else {
                g_sys_status = ST_MANUAL;
                motion_move_mm((float)cmd.x_mm, (float)cmd.y_mm);
            }
        }
    }
}

void vCommTask(void *arg)
{
    (void)arg;
    for (;;) {
        comm_uart_poll();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void vKeyTask(void *arg)
{
    (void)arg;
    for (;;) {
        key_scan();
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

void vDisplayTask(void *arg)
{
    (void)arg;
    for (;;) {
        printf("[pos] x=%ld.%03ld y=%ld.%03ld status=%u mode=%u\r\n",
               (long)(stepper_x_steps() / (int32_t)STEPS_PER_MM),
               (long)((stepper_x_steps() * 10 % (int32_t)(STEPS_PER_MM * 10)) * 100 / 10),
               (long)(stepper_y_steps() / (int32_t)STEPS_PER_MM),
               (long)((stepper_y_steps() * 10 % (int32_t)(STEPS_PER_MM * 10)) * 100 / 10),
               g_sys_status, g_auto_mode);
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

void vHeartbeatTask(void *arg)
{
    (void)arg;
    for (;;) {
        HAL_GPIO_TogglePin(LED_PORT, LED_PIN);
        comm_can_send_pos();
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

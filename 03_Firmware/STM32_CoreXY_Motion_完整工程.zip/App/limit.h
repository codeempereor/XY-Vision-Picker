#ifndef LIMIT_H
#define LIMIT_H

#include "app_config.h"

/* 限位开关：PC0..PC3 = X- / X+ / Y- / Y+，高电平触发（LIMIT_ACTIVE_LEVEL=1）。
 * 触发后立即停 TIM6 脉冲并置位标志（优先级最高中断）。 */

void limit_init(void);
uint8_t limit_xn(void);
uint8_t limit_xp(void);
uint8_t limit_yn(void);
uint8_t limit_yp(void);

extern volatile uint8_t g_limit_xn;
extern volatile uint8_t g_limit_xp;
extern volatile uint8_t g_limit_yn;
extern volatile uint8_t g_limit_yp;

#endif
